# Universal Gcode Sender - Classic

![Classic](https://github.com/winder/Universal-G-Code-Sender/raw/master/pictures/1.0.6_job_finished.png "Universal Gcode Sender - Classic")

This is the module for the *UGS Classic* edition. It is based on the same stable backend as the *UGS Platform* edition but has a bit fewer features.

To get started developing on the classic UI, check out these instructions: http://winder.github.io/ugs_website/dev/getting_started/