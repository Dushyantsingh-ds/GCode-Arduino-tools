/*
 */
package com.willwinder.universalgcodesender.gcode.util;

/**
 *
 * @author wwinder
 */
public class GcodeParserException extends Exception {
    public GcodeParserException(String s) {
        super(s);
    }
}
