﻿//
// Petes Stoopid-Simple TEXT to GCODE Converter Utility 
// One Font , One Purpose, KISS design
// 29th March 2020                          Version 1.0
//

using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //declare global vars HERE

        public Form1()
        {
            InitializeComponent();
            loadgcodelists(); // load up the gcode into the list of lists 
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // this is the button for CREATING THE GCODE
            Globals.Xofs = 0; // reset the horizontal offset
            try
            {
                Globals.theFlyheight = Convert.ToSingle(textBox3.Text);
            }
            catch
            {
                MessageBox.Show("invalid number in Fly Height textbox. Exiting");
                Application.Exit();
            }
            try
            {
                Globals.theCutheight = Convert.ToSingle(textBox4.Text);
            }
            catch
            {
                MessageBox.Show("invalid number in Cut Depth textbox. Exiting");
                Application.Exit();
            }
            try
            {
                Globals.theFontheight = Convert.ToSingle(textBox2.Text);
            }
            catch
            {
                MessageBox.Show("invalid number in Font Height textbox. Exiting");
                Application.Exit();
            }
            //////////////////////////////
            if (Globals.theFlyheight > 0.5)
            {
                Globals.Flyheight = "Z" + Globals.theFlyheight.ToString("0.000");
            }
            else
            {
                Globals.Flyheight = "Z5.0";
            }
            //
            Globals.Cutheight = "Z" + Globals.theCutheight.ToString("0.000");
            if (Globals.theFontheight < 0.5)
            {
                Globals.theFontheight =  0.5f;
            }
            Globals.Scalefactor = Globals.theFontheight / 18.0f;  // due to the grid size of my source font data
            //
            if (textBox1.Text != "")
            {
                // create the path of the output file - its going to be created on the desktop.
                string desktopPath = Environment.GetFolderPath( Environment.SpecialFolder.DesktopDirectory);
                string GCODEoutputfile = desktopPath + "\\OPFILE.GCODE";
                //open output file 
                System.IO.StreamWriter outputfile = new System.IO.StreamWriter(GCODEoutputfile);
                // Write header info to the GCODE output file
                outputfile.WriteLine(";Petes Stoopid-Simple TEXT to GCODE converter V1.0");
                outputfile.WriteLine(";29TH MARCH 2020 COVID19 WAVE1");
                outputfile.WriteLine("G21"); // metric coordinates system
                outputfile.WriteLine("F1000"); // set a default feed rate of 1 meter/minute
                ///////////////////////////////////////////////////////////////////////
                //                                                                   //
                //       WRITE ANY EXTRA GCODE HEADER THAT MAY BE REQIRED HERE       //
                //                                                                   //
                ///////////////////////////////////////////////////////////////////////
                Application.DoEvents();
                string thestring = textBox1.Text;
                //
                foreach (char thechar in thestring)  //do each char 
                {
                    // go through each char and process its GCODE through to output file
                    // start by searching though first char of each list to see which character matches
                    string tempstring = Globals.gList[1][3];
                    foreach (List<string> gcodestringlist in Globals.gList )
                    {
                        string atempstring = gcodestringlist[0];
                        if (gcodestringlist[0][0] == thechar)
                        {
                            // We get here when the first char of the present list element matches the 
                            // character in the input text string.
                            // We need to process this particular List of GCODE strings from elements 1 to N-1
                            // i.e for a list of 17 elements , item 0 is the first char so we want elements 1 to 16.
                            outputfile.WriteLine(";" + thechar);
                            int numberofitems = gcodestringlist.Count(); // ask it how many items are in the list
                            for (int i = 1; i < (numberofitems); i++)
                            {
                                string ls = gcodestringlist[i];
                                if (ls.Trim() == "ZF")
                                {
                                    outputfile.WriteLine(Globals.Flyheight);
                                }
                                else if (ls.Trim() == "ZC")
                                {
                                    outputfile.WriteLine(Globals.Cutheight);
                                }
                                else
                                {
                                    getcoords(ls); //its probably an XY coord so parse it and get the X & Y values
                                    //modify the XY coords
                                    Globals.Xnew = Globals.GX + Globals.Xofs;
                                    Globals.Ynew = Globals.GY;
                                    //Font size requires scaling the X&Y coords !
                                    Globals.Xnew = Globals.Xnew * Globals.Scalefactor;
                                    Globals.Ynew = Globals.Ynew * Globals.Scalefactor;
                                    // generate a string with the new XY coords 
                                    string Xnewcoord = Globals.Xnew.ToString("0.000");
                                    string Ynewcoord = Globals.Ynew.ToString("0.000");
                                    string newstring = "X" + Xnewcoord + " Y" + Ynewcoord;
                                    //outputfile.WriteLine(gcodestringlist[i]); // write to o/p file 
                                    outputfile.WriteLine(newstring); // write to o/p file 
                                }
                                //
                            }
                            // and now we increment the X offset to move teh next character so it
                            // doesnt overwite the previous one
                            //Globals.Xofs = Globals.Xofs + (18 * Globals.Scalefactor);
                            Globals.Xofs = Globals.Xofs + 18;
                        }

                    }
                    // Move to next char:
                    // Add a scaled amount to X ORIGIN coord
                }
                outputfile.Close();
            }
            else
            {
                MessageBox.Show("textbox empty, nothing to process");
            }
        }

        public void loadgcodelists()
        {
            Globals.gList.Add(new List<string>
            {
             "0",
             "ZF",
             "X1 Y2",
             "ZC",
             "X11 Y16",
             "ZF",
             "X12 Y12",
             "ZC",
             "X12 Y6",
             "X9 Y0",
             "X3 Y0",
             "X0 Y6",
             "X0 Y12",
             "X3 Y18",
             "X9 Y18",
             "X12 Y12",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "1",
             "ZF",
             "X3 Y0",
             "ZC",
             "X9 Y0",
             "X6 Y0",
             "X6 Y18",
             "X3 Y15",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "2",
             "ZF",
             "X0 Y15",
             "ZC",
             "X3 Y18",
             "X9 Y18",
             "X12 Y15",
             "X12 Y11",
             "X2 Y5",
             "X0 Y0",
             "X12 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "3",
             "ZF",
             "X0 Y2",
             "ZC",
             "X3 Y0",
             "X9 Y0",
             "X12 Y3",
             "X12 Y7",
             "X9 Y9",
             "X3 Y9",
             "X9 Y9",
             "X12 Y11",
             "X12 Y15",
             "X9 Y18",
             "X3 Y18 ",
             "X0 Y16",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "4",
             "ZF",
             "X9 Y0",
             "ZC",
             "X9 Y18",
             "X0 Y6",
             "X12 Y6",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "5",
             "ZF",
             "X0 Y2",
             "ZC",
             "X3 Y0",
             "X9 Y0",
             "X12 Y2",
             "X12 Y8",
             "X9 Y10",
             "X3 Y10",
             "X0 Y9",
             "X2 Y18",
             "X12 Y18",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "6",
             "ZF",
             "X0 Y7",
             "ZC",
             "X3 Y10",
             "X9 Y10",
             "X12 Y7",
             "X12 Y3",
             "X9 Y0",
             "X3 Y0",
             "X0 Y3",
             "X0 Y10",
             "X3 Y15",
             "X7 Y18",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "7",
             "ZF",
             "X0 Y18",
             "ZC",
             "X12 Y18",
             "X4 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "8",
             "ZF",
             "X9 Y10",
             "ZC",
             "X12 Y13",
             "X12 Y15",
             "X9 Y18",
             "X3 Y18",
             "X0 Y15",
             "X0 Y13",
             "X3 Y10",
             "X9 Y10",
             "X12 Y7",
             "X12 Y3",
             "X9 Y0",
             "X3 Y0",
             "X0 Y3",
             "X0 Y7",
             "X3 Y10",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "9",
             "ZF",
             "X5 Y0",
             "ZC",
             "X9 Y3",
             "X12 Y8",
             "X12 Y15",
             "X9 Y18",
             "X3 Y18",
             "X0 Y15",
             "X0 Y11",
             "X3 Y8",
             "X9 Y8",
             "X12 Y11",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             ".",
             "ZF",
             "X6 Y0",
             "ZC",
             "ZF"
            });


            Globals.gList.Add(new List<string>
            {
             "a",
             "ZF",
             "X0 Y10",
             "ZC",
             "X5 Y12",
             "X11 Y10",
             "X11 Y2",
             "X8 Y0",
             "X4 Y0",
             "X0 Y2",
             "X0 Y5",
             "X11 Y6",
             "X11 Y2",
             "X13 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "b",
             "ZF",
             "X0 Y18",
             "ZC",
             "X0 Y0",
             "X0 Y2",
             "X6 Y0",
             "X12 Y2",
             "X12 Y9",
             "X6 Y11",
             "X0 Y9",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "c",
             "ZF",
             "X11 Y9",
             "ZC",
             "X6 Y11",
             "X0 Y9",
             "X0 Y2",
             "X6 Y0",
             "X11 Y2",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "d",
             "ZF",
             "X12 Y9",
             "ZC",
             "X6 Y11",
             "X0 Y9",
             "X0 Y2",
             "X6 Y0",
             "X12 Y2",
             "X12 Y0",
             "X12 Y18",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "e",
             "ZF",
             "X0 Y6",
             "ZC",
             "X12 Y7",
             "X9 Y12",
             "X3 Y12",
             "X0 Y9",
             "X0 Y2",
             "X3 Y0",
             "X9 Y0",
             "X12 Y2",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "f",
             "ZF",
             "X0 Y9",
             "ZC",
             "X8 Y9",
             "ZF",
             "X12 Y16",
             "ZC",
             "X8 Y18",
             "X4 Y16",
             "X4 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "g",
             "ZF",
             "X11 Y2",
             "ZC",
             "X6 Y0",
             "X0 Y2",
             "X0 Y9",
             "X6 Y11",
             "X11 Y9",
             "X11 Y11",
             "X11 Y-5",
             "X6 Y-7",
             "X0 Y-5",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "h",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "ZF",
             "X0 Y9",
             "ZC",
             "X6 Y11",
             "X12 Y9",
             "X12 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "i",
             "ZF",
             "X7 Y0",
             "ZC",
             "X7 Y11",
             "X4 Y11",
             "ZF",
             "X7 Y18",
             "ZC",
             "X6 Y18",
             "X6 Y17",
             "X7 Y17",
             "X7 Y18",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "j",
             "ZF",
             "X0 Y-5",
             "ZC",
             "X4 Y-7",
             "X8 Y-5",
             "X8 Y11",
             "ZF",
             "X8 Y18",
             "ZC",
             "X7 Y18",
             "X7 Y17",
             "X8 Y17",
             "X8 Y18",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "k",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "ZF",
             "X0 Y5",
             "ZC",
             "X12 Y11",
             "ZF",
             "X4 Y7",
             "ZC",
             "X12 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "l",
             "ZF",
             "X3 Y18",
             "ZC",
             "X6 Y18",
             "X6 Y0",
             "X3 Y0",
             "X9 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "m",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y12",
             "X0 Y9",
             "X4 Y12",
             "X6 Y9",
             "X6 Y0",
             "ZF",
             "X6 Y9",
             "ZC",
             "X10 Y12",
             "X12 Y9",
             "X12 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "n",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y11",
             "X0 Y8",
             "X6 Y11",
             "X12 Y8",
             "X12 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "o",
             "ZF",
             "X6 Y0",
             "ZC",
             "X12 Y2",
             "X12 Y9",
             "X6 Y11",
             "X0 Y9",
             "X0 Y2",
             "X6 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "p",
             "ZF",
             "X0 Y-7",
             "ZC",
             "X0 Y11",
             "X0 Y9",
             "X6 Y11",
             "X12 Y9",
             "X12 Y2",
             "X6 Y0",
             "X0 Y2",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "q",
             "ZF",
             "X11 Y2",
             "ZC",
             "X6 Y0",
             "X0 Y2",
             "X0 Y9",
             "X6 Y11",
             "X11 Y9",
             "X11 Y11",
             "X11 Y-6",
             "X13 Y-8",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "r",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y11",
             "X0 Y8",
             "X6 Y11",
             "X12 Y8",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "s",
             "ZF",
             "X0 Y2",
             "ZC",
             "X6 Y0",
             "X12 Y2",
             "X12 Y5",
             "X0 Y7",
             "X0 Y10",
             "X6 Y12",
             "X12 Y10",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "t",
             "ZF",
             "X0 Y11",
             "ZC",
             "X8 Y11",
             "ZF",
             "X4 Y18",
             "ZC",
             "X4 Y2",
             "X8 Y0",
             "X12 Y2",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "u",
             "ZF",
             "X0 Y11",
             "ZC",
             "X0 Y2",
             "X6 Y0",
             "X12 Y2",
             "X12 Y11",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "v",
             "ZF",
             "X0 Y11",
             "ZC",
             "X6 Y0",
             "X12 Y11",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "w",
             "ZF",
             "X0 Y11",
             "ZC",
             "X3 Y0",
             "X6 Y8",
             "X9 Y0",
             "X12 Y11",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "x",
             "ZF",
             "X0 Y0",
             "ZC",
             "X11 Y11",
             "ZF",
             "X0 Y11",
             "ZC",
             "X11 Y0",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "y",
             "ZF",
             "X0 Y11",
             "ZC",
             "X7 Y1",
             "ZF",
             "X3 Y-7",
             "ZC",
             "X12 Y11",
             "ZF"
            });
            Globals.gList.Add(new List<string>
            {
             "z",
             "ZF",
             "X0 Y11",
             "ZC",
             "X12 Y11",
             "X0 Y0",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             " ",
             "ZF"
            });


            Globals.gList.Add(new List<string>
            {
             "A",
             "ZF",
             "X0 Y0",
             "ZC",
             "X6 Y18",
             "X12 Y0",
             "ZF",
             "X3 Y9",
             "ZC",
             "X9 Y9",
             "ZF"

            });


            Globals.gList.Add(new List<string>
            {
             "B",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "X9 Y18",
             "X12 Y15",
             "X12 Y12",
             "X9 Y9",
             "X0 Y9",
             "X9 Y9",
             "X12 Y6",
             "X12 Y3",
             "X9 Y0",
             "X0 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "C",
             "ZF",
             "X12 Y3",
             "ZC",
             "X9 Y0",
             "X3 Y0",
             "X0 Y3",
             "X0 Y15",
             "X3 Y18",
             "X9 Y18",
             "X12 Y15",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "D",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "X9 Y18",
             "X12 Y15",
             "X12 Y3",
             "X9 Y0",
             "X0 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "E",
             "ZF",
             "X9 Y9",
             "ZC",
             "X0 Y9",
             "ZF",
             "X12 Y18",
             "ZC",
             "X0 Y18",
             "X0 Y0",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "F",
             "ZF",
             "X9 Y9",
             "ZC",
             "X0 Y9",
             "ZF",
             "X12 Y18",
             "ZC",
             "X0 Y18",
             "X0 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "G",
             "ZF",
             "X12 Y15",
             "ZC",
             "X9 Y18",
             "X3 Y18",
             "X0 Y15",
             "X0 Y3",
             "X3 Y0",
             "X9 Y0",
             "X12 Y3",
             "X12 Y8",
             "X5 Y8",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "H",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "ZF",
             "X12 Y0",
             "ZC",
             "X12 Y18",
             "ZF",
             "X0 Y9",
             "ZC",
             "X12 Y9",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "I",
             "ZF",
             "X2 Y0",
             "ZC",
             "X10 Y0",
             "X6 Y0",
             "X6 Y18",
             "X2 Y18",
             "X10 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "J",
             "ZF",
             "X0 Y2",
             "ZC",
             "X3 Y0",
             "X5 Y0",
             "X8 Y2",
             "X8 Y18",
             "X4 Y18",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "K",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "ZF",
             "X12 Y18",
             "ZC",
             "X0 Y6",
             "X3 Y9",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "L",
             "ZF",
             "X0 Y18",
             "ZC",
             "X0 Y0",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "M",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "X6 Y5",
             "X12 Y18",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "N",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "X12 Y0",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "O",
             "ZF",
             "X3 Y0",
             "ZC",
             "X9 Y0",
             "X12 Y3",
             "X12 Y15",
             "X9 Y18",
             "X3 Y18",
             "X0 Y15",
             "X0 Y3",
             "X3 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "P",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "X9 Y18",
             "X12 Y15",
             "X12 Y11",
             "X9 Y8",
             "X0 Y8",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "Q",
             "ZF",
             "X3 Y0",
             "ZC",
             "X9 Y0",
             "X12 Y3",
             "X12 Y15",
             "X9 Y18",
             "X3 Y18",
             "X0 Y15",
             "X0 Y3",
             "X3 Y0",
             "ZF",
             "X7 Y5",
             "ZC",
             "X14 Y-2",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "R",
             "ZF",
             "X0 Y0",
             "ZC",
             "X0 Y18",
             "X9 Y18",
             "X12 Y15",
             "X12 Y11",
             "X9 Y8",
             "X0 Y8",
             "X7 Y8",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "S",
             "ZF",
             "X0 Y2",
             "ZC",
             "X3 Y0",
             "X9 Y0",
             "X12 Y3",
             "X12 Y6",
             "X9 Y9",
             "X3 Y9",
             "X0 Y12",
             "X0 Y15",
             "X3 Y18",
             "X9 Y18",
             "X12 Y16",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "T",
             "ZF",
             "X6 Y0",
             "ZC",
             "X6 Y18",
             "X0 Y18",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "U",
             "ZF",
             "X0 Y18",
             "ZC",
             "X0 Y3",
             "X3 Y0",
             "X9 Y0",
             "X12 Y3",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "V",
             "ZF",
             "X0 Y18",
             "ZC",
             "X6 Y0",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "W",
             "ZF",
             "X0 Y18",
             "ZC",
             "X3 Y0",
             "X6 Y14",
             "X9 Y0",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "X",
             "ZF",
             "X0 Y0",
             "ZC",
             "X12 Y18",
             "ZF",
             "X0 Y18",
             "ZC",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "Y",
             "ZF",
             "X0 Y18",
             "ZC",
             "X6 Y8",
             "X6 Y0",
             "X6 Y8",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "Z",
             "ZF",
             "X0 Y18",
             "ZC",
             "X12 Y18",
             "X0 Y0",
             "X12 Y0",
             "ZF"
            });


            Globals.gList.Add(new List<string>
            {
             "&",
             "ZF",
             "X12 Y5",
             "ZC",
             "X8 Y0",
             "X2 Y0",
             "X0 Y4",
             "X9 Y14",
             "X7 Y18",
             "X3 Y18",
             "X1 Y14",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "'",
             "ZF",
             "X5 Y18",
             "ZC",
             "X5 Y18",
             "X7 Y14",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "@",
             "ZF",
             "X12 Y2",
             "ZC",
             "X10 Y0",
             "X3 Y0",
             "X0 Y3",
             "X0 Y15",
             "X3 Y18",
             "X9 Y18",
             "X12 Y15",
             "X12 Y6",
             "X5 Y6",
             "X5 Y13",
             "X12 Y13",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "\\",
             "ZF",
             "X0 Y18",
             "ZC",
             "X12 Y0",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "}",
             "ZF",
             "X0 Y-2",
             "ZC",
             "X5 Y1",
             "X5 Y6",
             "X8 Y9",
             "X5 Y12",
             "X5 Y17",
             "X0 Y20",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             ")",
             "ZF",
             "X0 Y-2",
             "ZC",
             "X6 Y4",
             "X6 Y14",
             "X0 Y20",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "]",
             "ZF",
             "X0 Y-2",
             "ZC",
             "X6 Y-2",
             "X6 Y20",
             "X0 Y20",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             ":",
             "ZF",
             "X6 Y14",
             "ZC",
             "ZF",
             "X6 Y4",
             "ZC",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             ",",
             "ZF",
             "X4 Y-4",
             "ZC",
             "X6 Y1",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "$",
             "ZF",
             "X0 Y3",
             "ZC",
             "X3 Y1",
             "X9 Y1",
             "X12 Y3",
             "X12 Y7",
             "X9 Y9",
             "X3 Y9",
             "X0 Y11",
             "X0 Y15",
             "X3 Y17",
             "X9 Y17",
             "X12 Y15",
             "ZF",
             "X6 Y19",
             "ZC",
             "X6 Y-1",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "\"",
             "ZF",
             "X3 Y14",
             "ZC",
             "X4 Y18",
             "ZF",
             "X7 Y14",
             "ZC",
             "X8 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "=",
             "ZF",
             "X0 Y4",
             "ZC",
             "X12 Y4",
             "ZF",
             "X0 Y14",
             "ZC",
             "X12 Y14",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "!",
             "ZF",
             "X6 Y18",
             "ZC",
             "X6 Y5",
             "ZF",
             "X6 Y0",
             "ZC",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "/",
             "ZF",
             "X0 Y0",
             "ZC",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             ">",
             "ZF",
             "X0 Y0",
             "ZC",
             "X12 Y9",
             "X0 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "#",
             "ZF",
             "X2 Y0",
             "ZC",
             "X4 Y18",
             "ZF",
             "X10 Y18",
             "ZC",
             "X8 Y0",
             "ZF",
             "X12 Y5",
             "ZC",
             "X0 Y5",
             "ZF",
             "X0 Y13",
             "ZC",
             "X12 Y13",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "<",
             "ZF",
             "X12 Y0",
             "ZC",
             "X0 Y9",
             "X12 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "-",
             "ZF",
             "X0 Y9",
             "ZC",
             "X12 Y9",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "{",
             "ZF",
             "X12 Y-2",
             "ZC",
             "X7 Y1",
             "X7 Y6",
             "X4 Y9",
             "X7 Y12",
             "X7 Y17",
             "X12 Y20",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "(",
             "ZF",
             "X12 Y-2",
             "ZC",
             "X6 Y4",
             "X6 Y14",
             "X12 Y20",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "[",
             "ZF",
             "X12 Y-2",
             "ZC",
             "X6 Y-2",
             "X6 Y20",
             "X12 Y20",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "|",
             "ZF",
             "X6 Y0",
             "ZC",
             "X6 Y6",
             "ZF",
             "X6 Y12",
             "ZC",
             "X6 Y18",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "%",
             "ZF",
             "X0 Y0",
             "ZC",
             "X12 Y18",
             "ZF",
             "X6 Y14",
             "ZC",
             "X3 Y18",
             "X0 Y14",
             "X3 Y10",
             "X6 Y14",
             "ZF",
             "X9 Y8",
             "ZC",
             "X12 Y4",
             "X9 Y0",
             "X6 Y4",
             "X9 Y8",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "+",
             "ZF",
             "X6 Y2",
             "ZC",
             "X6 Y16",
             "ZF",
             "X0 Y9",
             "ZC",
             "X12 Y9",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "?",
             "ZF",
             "X6 Y0",
             "ZC",
             "ZF",
             "X6 Y4",
             "ZC",
             "X6 Y7",
             "X12 Y11",
             "X12 Y15",
             "X9 Y18",
             "X3 Y18",
             "X0 Y15",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "^",
             "ZF",
             "X0 Y7",
             "ZC",
             "X6 Y16",
             "X12 Y7",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             ";",
             "ZF",
             "X5 Y-4",
             "ZC",
             "X7 Y0",
             "ZF",
             "X7 Y10",
             "ZC",
             "ZF"
            });

            Globals.gList.Add(new List<string>
            {
             "*",
             "ZF",
             "X3 Y2",
             "ZC",
             "X9 Y16",
             "ZF",
             "X3 Y16",
             "ZC",
             "X9 Y2",
             "ZF",
             "X12 Y9",
             "ZC",
             "X0 Y9",
             "ZF"
            });
        }

        public void getcoords(string thestring)
        {
            // Parse a string in the form "X3 Y8" for example, and set the global variables GX and GY to the 
            // X & Y values from the string
            // - expects coords to be in X Y pairs like in the example shown
            // - expects X coord and THEN the Y coord in that order !!!
            string nstring = thestring.Trim().ToUpper();
            int Xpos = nstring.LastIndexOf("X"); // get the location of the X
            int Ypos = nstring.LastIndexOf("Y"); // get the location of the Y
            if ((Xpos == -1) | (Ypos == -1))
            {
                MessageBox.Show("input line doesnt have both X & Y coords!! Unexpected input data");
                Application.Exit();
            }
            else
            {
                //it has both X & Y coordinates so lets process it 
                if (Ypos > Xpos) // means Y is after X on the line , just take stuff after the Y character
                {
                    string theYbit = nstring.Substring(Ypos + 1);   // take ths string after the Y
                    string theXbit = nstring.Substring(1, Ypos-1).Trim();   // take the string before the Y and after the X
                    Globals.GX = Convert.ToSingle(theXbit);
                    Globals.GY = Convert.ToSingle(theYbit);
                    // int ac = 1;
                }

            }

            // int a = 1;
        }





    }




    public static class Globals
    {
        //
        // NOTE THAT THIS ABSOLUTELY MUST BE PLACED AFTER THE Form1 CLASS 
        // OTHERWISE THE IDE THROWS AN ERROR WHEN YOU TRY TO SEE THE FORM LAYOUT.
        //

        // the next two lines are the example from stack exchange:
        public static String ExampleStringVarName = "Mike"; // Modifiable in Code  
        public const Int32 ExamplevariableValue = 10; // Unmodifiable

        public static List<List<string>> gList = new List<List<string>>(); // hopefully this is a list of lists  of strings

        public static float GX = 0;                     // Gcode X value from file
        public static float GY = 0;                     // Gcode Y value from file
        public static float Xnew = 0;                     // Xnew value 
        public static float Ynew = 0;                     // Ynew value
        public static float Xofs = 0;                   // X offset , used to move the position of the output letters as we go
        public static float theFlyheight = 5;
        public static float theCutheight = -1;
        public static float theFontheight = 12;
        public static string Flyheight;
        public static string Cutheight;
        public static string Fontheight;
        public static float Scalefactor;
        // to access a global var elsewhere you just say (for example)    Globals.portopen = true;

    }

}

